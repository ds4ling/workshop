# Codebook

## learner_data.csv

- A comma separated data file 
- Contains data from 80 participants on a language proficiency test
- 3 columns
	- experience: the amount of experience in years of the participant
	- children_s: scores from participants who learned their L2 during childhood
	- adults_s: scores from participants who learned their L2 as adults
