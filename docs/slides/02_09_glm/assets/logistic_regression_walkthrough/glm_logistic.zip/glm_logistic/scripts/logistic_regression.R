library("tidyverse")
library("lingStuff")
library("sjPlot")

# 1. Load the data
titanic <- read_csv("./data/titanic.csv")

# 2. Get to know the data (how many columns? what do they represent?)
glimpse(titanic)
summary(titanic)

# 3. Think of 2 hypotheses you could test

# 4. Fit the appropriate models to test your hypotheses

# 5. Attempt to plot the data (include model fit)
# Try: sjPlot(MODEL_NAME)



# helpers
# method.args = list(family = "binomial")
# lingStuff::inv_logit()
# inv_logit_manual <- function(x){1 / (1 + exp(-x))}
# inv_logit_manual(coef(mod)[1] + coef(mod)[2] * mean(data$col))
